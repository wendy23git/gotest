## code2png
markdown code 替换为图片

## 使用方法

```
git clone git@github.com:gusibi/oneplus.git

cd oneplus/code2png

python plus.py -m [markdown_path] -n [outfile_path]

```

## html-server

改目录为 code html 页面渲染服务


## 示例 

这是转换前：

https://github.com/gusibi/oneplus/blob/master/325.md

这是转换后：

https://github.com/gusibi/oneplus/blob/master/new_325.md
