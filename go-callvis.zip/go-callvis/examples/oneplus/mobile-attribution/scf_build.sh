GOOS=linux GOARCH=amd64 go build -o main scf_main.go
zip mobile.zip main
