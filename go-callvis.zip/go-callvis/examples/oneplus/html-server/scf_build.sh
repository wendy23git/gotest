GOOS=linux GOARCH=amd64 go build -o main scf_main.go
zip html-server.zip main
